/*
 * Day1_Task3_Button_LED_Solution.c
 *
 * Author : J�rgen Steen
 *
 * Setup: OLED extension connected to ext1 of theAttiny817 Xplained Pro
 * Function: Toggles LED 1 when button 1 is pressed
 * The LEDS are active LOW and button does not have a pull-up resistor.
 */

 #include <avr/io.h>         // A part of all AVR-programming for convenient programming
 #define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
 #include <util/delay.h>     //Delay Library


int main(void)
{
	PORTB.DIR |= 0b00000001;   //Sets PB0(PORTB pin 0) as an output. Can also be written PORTB.DIR |= (1<<0);
	PORTA.DIR &= ~0b00100000; //Sets PA5 as an input. They are set as this by default, but this makes it explicits for the reader.
	PORTA.PIN5CTRL |= (1<<3);  //Turns on the pull-up resistor on PORTA5/button1

	while (1)
	{
		if (!(PORTA.IN & 0b00100000))
		{
			PORTB.OUT = PORTB.OUT ^ 0b00000001;  // PB0 is toggeled. Can also be written PORTB.OUT ^= (1<<0);
			_delay_ms(500); //Waits for 500ms
		}
	}
}