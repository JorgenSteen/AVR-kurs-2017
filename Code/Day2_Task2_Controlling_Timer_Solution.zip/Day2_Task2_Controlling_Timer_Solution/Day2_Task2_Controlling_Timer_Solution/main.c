/*
 * Day2_Task2_Controlling_Timer_Solution.c
 *
 * Dag_2_Opgave_2_Controlled_timer_LF.c
 *
 * Author : J�rgen Steen
 * Setup: OLED exention connected to ext1 of theAttiny817 Xplained Pro
 * Function: In this program we use 1 of the chips clock to create multiple times, one of which is controlled with buttons.
			 Button 1 starts timer1 and button 2 stops it. This is is indicated with the led blinking. Led 2 blinks undisturbed.
 */

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include <avr/interrupt.h>  //Atmel's own interrupt library

#define LED1_bm (1<<0) //LED1 on OLED
#define LED2_bm (1<<1) //LED2 on OLED
#define Button1_bm (1<<5) //button1 on OLED
#define Button2_bm (1<<6) //button2 on OLED
#define button1_check (!(PORTA.IN & Button1_bm)) //button1 check to make it short and more understandable in the code.
#define button2_check (!(PORTA.IN & Button2_bm)) //button2 check
//Defining my own boolean commands
#define TRUE 1
#define FALSE 0
//Creating flags for each button to stop de-bouncing and them from being activated multiple times if they are being held down
uint8_t Button1_flag = FALSE;
uint8_t Button2_flag = FALSE;



//timer defines and variables. It might seem tedious to define it here, but now if you change it just here everything will follow.
#define t1 200  //timer 1 value
#define t2 300 //timer 2 value
#define t3 100 //Button timer value 
uint8_t timer1; //Initiates the timer1. Since they are 8bit the max value is 255.
uint16_t timer2; //Initiates the timer2. 16bit the max value is 65536, which should suffice
uint8_t Button_timer1, Button_timer2; //timers to ensure software de-bouncing
uint8_t blink_on = FALSE; //Decides if the timer should start on or off.

//This function checks all of the timers and resets them if they have reached 0.
void Time_check(void)
{
	//timer one is controlled with the buttons
	if ( timer1 == 0)
	{
		PORTB.OUT ^= LED1_bm; 
		timer1 = t1; //Sets timer 1 to its initial value.
	}
	//Timer 2 blinks regardless of what else is happening.
	if (timer2 == 0)
	{
		PORTB.OUT ^= LED2_bm;
		timer2 = t2; //sets timer 2 to its initial value.
	}
	//Sets the flag low after the given time(de-bouncing).
	if (Button_timer1 == 0)
	{
		Button1_flag = FALSE; 
	}
	if ((Button_timer2 == 0) && (Button2_flag == TRUE))
	{
		Button2_flag = FALSE;
	}
}

//A function that checks the status of the buttons
void Button_check(void)
{
	if (button1_check)
	{
		if (Button1_flag == FALSE)
		{
			blink_on = TRUE;  //Turns on the blink timer
			Button1_flag = TRUE;   //Sets the button flag high
		}
		Button_timer1 = t3;  //Sets the button timer for de-bouncing and anti-hold
	}
	if (button2_check)
	{
		if (Button2_flag == FALSE)
		{
			blink_on = FALSE;    //Turns on the blink timer
			Button2_flag = TRUE;   //Sets the button flag high
		}
		Button_timer2 = t3; //Sets the button timer for de-bouncing and anti-hold
	}
}
void init_general(void)
{
	PORTB.DIR |= LED1_bm | LED2_bm ; //Sets PB0 and 1 outputs, which are connected to LED 1 and 2
	PORTA.DIR &= ~Button1_bm & ~Button2_bm; //Sets PA4 and 5 as inputs. They are set as this by default, but this makes it explicits for the reader.
	PORTA.PIN5CTRL |= (1<<3); //Turns on the pull-up resistor on PORTA5/button1
	PORTA.PIN6CTRL |= (1<<PORT_PULLUPEN_bp); //Same with PORTA6/button2, but with use of Atmel's bit postion(bp) name.
}
void init_timer(void)
{
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm | TCA_SINGLE_CLKSEL_DIV256_gc;  //Turns on time counter A and sets the prescale value to 256 . 3333333/256= 130020hz (TCA0.SINGLE.CTRLA |=0b00001101)
	TCA0.SINGLE.INTCTRL |= (1<<TCA_SINGLE_OVF_bp) ; //Turns on the overflow timer on Time counter A
	TCA0.SINGLE.PER = 13; //Choose the top value to be 13 130020/13= 1000hz
	timer1 = t1;  //sets time 1 to timer 1
	timer2 = t2;  //Sets time 2 to timer 2
	Button_timer1 = t3; //Sets timer3 to the button 1 timer.
	Button_timer2 = t3; //Sets timer3 to the button 2 timer.
	sei(); //turns on ISP(interrupt service routine).
}

int main(void)
{
	init_general(); //Calls the functions that turns on LED,buttons etc.
	init_timer();  //Calls the function that initiates everything for the timer.
    while (1) 
    {
		Time_check(); //Checks if the timers have counted to 0.
		Button_check(); //Check if the buttons have been pressed
    }
}
//interrupt service routine function that gets called upon every 1ms ((256*13)/3333333) = 1ms(ish)
ISR(TCA0_OVF_vect)
{
	//Timer 1 counts if the timer is turned on. 
	if (blink_on == TRUE)
	{
		if (timer1 > 0)
		{
			timer1 = timer1 - 1; 
		}
	}
	//timer2 counter
	if (timer2 > 0)
	{	
		timer2--;
	}
	//Counts down the button timer if their value has been set.
	if (Button_timer1> 0)
	{
		Button_timer1--;
	}
	if (Button_timer2> 0)
	{
		Button_timer2--;
	}
	TCA0.SINGLE.INTFLAGS |= (1<<TCA_SINGLE_OVF_bp); //Turns off the interrupt flag so that the ISR can be called again
}