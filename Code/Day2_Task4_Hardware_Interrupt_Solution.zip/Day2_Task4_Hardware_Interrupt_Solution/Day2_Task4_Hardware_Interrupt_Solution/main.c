/*
 * Day2_Task4_Hardware_Interrupt_Solution.c
 *
 * Created: 05.04.2017 20:15:54
 * Author : J�rgen Steen
 * Setup: OLED extension connected to ext1 of theAttiny817 Xplained Pro
 * Function: Using a hardware interrupt with a button to toggle a led.
  */

 #include <avr/io.h>         // A part of all AVR-programming for convenient programming
 #define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
 #include <util/delay.h>     //Delay Library
 #include <avr/interrupt.h>  //Atmel's own interrupt library

#define LED1_bm (1<<0) //LED1 on OLED ext1
#define Button1_bm (1<<5) //Button1 on OLED ext1
#define Button1_check (!(PORTA.IN & Button1_bm))  //button1 check to make it short and more understandable in the code.
//Defining my own boolean commands
#define TRUE 1   
#define FALSE 0
//Creating flags for button1 to keep it from being activated multiple times if it is being held down
uint8_t Button1_flag = FALSE;  

ISR(PORTA_PORT_vect)
{
	//checks the status of button 1. It should be high, but this ISR gets activated by any PORTA interrupt
	if (Button1_check)
	{
		if (Button1_flag ==  FALSE)
		{
			Button1_flag = TRUE; //Sets the button flag high
			PORTB.OUT ^= LED1_bm; //This can be changed with any action, or a flag.
			_delay_ms(30); //delay to reduce de-bouncing. Would be better to have a timer. (Look at task 1)
		}
	}
	PORTA.INTFLAGS |= PORT_INT5_bm; //Turns off the interrupt flag so that the ISR can be called again
}
void init_generelt(void)
{
	PORTB.DIR |=  LED1_bm; //Sets PB5 as an output
	PORTA.DIR &= ~Button1_bm; //Sets PA5 as an input. They are set as this by default, but this makes it explicits for the reader.
	PORTA.PIN5CTRL |= (1<<PORT_PULLUPEN_bp);  //Turns on the pull-up resistor on PORTA5/button1
	PORTA.PIN5CTRL |= PORT_ISC_FALLING_gc;	// falling edge on PA5. This is preferred when the button is pulled up
	sei();  //turns on ISP(interrupt service routine).
}
//this button reads the button value and sets the flag low if its not in
void Button_check(void)
{
	if (!Button1_check)
	{
		Button1_flag = FALSE; //Sets the flag low
	}
}
int main(void)
{
	init_generelt(); //Calls the functions that turns on LED,buttons etc.
	while (1)
	{
		Button_check(); //Checks button status
	}
}

