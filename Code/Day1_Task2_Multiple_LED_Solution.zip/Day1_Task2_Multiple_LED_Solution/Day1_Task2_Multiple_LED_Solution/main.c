/*
 * Day1_Task2_Multiple_LED_Solution.c
 *
 * Author : J�rgen Steen
 *
 * Setup: OLED extension connected to ext1 of theAttiny817 Xplained Pro
 * Function: Turn multiple LEDs on and then off without affecting the other parts of the register.
 * The LEDS are active LOW
 */ 

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library

int main(void)
{
	PORTB.DIR = PORTB.DIR | 0b00010011;   //Sets PB0,1,4(PORTB pin 0,1,4) as an outputs. Can also be written PORTB.DIR |= 0b00010011;

	while(1)
	{
		PORTB.OUT = PORTB.OUT | 0b00000010;  // PB1 (PORTB pin 1) is set HIGH so the LED turns off. Can also be written PORTB.OUT |= 0b00000010;
		_delay_ms(1000); //Waits for 1000ms
		PORTB.OUT = PORTB.OUT & ~(0b00000010); // PB1(PORTB pin 1) is set LOW so the LED turns on. Can also be written PORTB.OUT &= ~0b00000010;
		_delay_ms(1000);  //Waits for 1 1000ms
		PORTB.OUT = PORTB.OUT | 0b00010001;  // PB0,4(PORTB pin 0,4) is set HIGH so the LED turns off. Can also be written PORTB.OUT |= 0b00010001;
		_delay_ms(1000); //Waits for 1000ms
		PORTB.OUT = PORTB.OUT & ~(0b00010001); // PB0,4(PORTB pin 0,4) is set LOW so the LED turns on. Can also be written PORTB.OUT &= ~0b00010001;
		_delay_ms(1000);  //Waits for 1 1000ms
	}
}

