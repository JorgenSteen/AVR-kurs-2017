/*
 * Day1_Extra_task_Button_LED_2_Solution.c
 *
 * Setup: OLED extension connected to ext1 of theAttiny817 Xplained Pro
 * Function: toggles the LED when a button is pressed, but only 1 time per press.
 * The LEDS are active LOW and button does not have a pull-up resistor.
 */

 #include <avr/io.h>         // A part of all AVR-programming for convenient programming
 #define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
 #include <util/delay.h>     //Delay Library
 #define button1_bm 0b00100000 //PA5  PORTA PIN 5 Button 1 on the OLED ext

 //Defining my own boolean commands
 #define TRUE 1
 #define FALSE 0

//Creating flags for button1 to keep it from being activated multiple times if it is being held down
uint8_t Button1_flag = FALSE;

int main(void)
{
	PORTB.DIR |= 0b00000001;   //Sets PB0(PORTB pin 0) as an output. Can also be written PORTB.DIR |= (1<<0);
	PORTA.DIR &= ~button1_bm; //Sets PB3 as an input. They are set as this by default, but this makes it explicits for the reader.
	PORTA.PIN5CTRL |= (1<<PORT_PULLUPEN_bp);  //Turns on the pull-up resistor on PORTA5/button1

	while (1)
	{
		if (!(PORTA.IN & button1_bm))
		{
			if (Button1_flag == FALSE)
			{
				Button1_flag = TRUE;
				PORTB.OUT = PORTB.OUT ^ 0b00000001;  // PB0 is toggeled. Can also be written PORTB.OUT ^= (1<<0);
				_delay_ms(500); //Waits for 500ms
			}
		}
		else
		{
			Button1_flag = FALSE;
		}
	}
}