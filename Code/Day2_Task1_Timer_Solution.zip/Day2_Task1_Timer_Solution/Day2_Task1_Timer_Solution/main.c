/*
 * Day2_Task1_Timer_Solution.c
 *
 * Author : J�rgen Steen
 * Setup: OLED exention connected to ext1 of theAttiny817 Xplained Pro
 * Function: I this program a timer blinks with 2hz by being toggled by a 1hz timer.
 */

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include <avr/interrupt.h>  //Atmel's own interrupt library

#define LED1_bm (1<<0) //LED1 on OLED
//Defining my own boolean commands
#define TRUE 1
#define FALSE 0



//Counter is decides the period of the interrupt. ((prescaler*counter)/3333333))= 1s.  
#define counter 13021   //timer 1 value




void init_general(void)
{
	PORTB.DIR |= LED1_bm;
}
void init_timer(void)
{
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm | TCA_SINGLE_CLKSEL_DIV256_gc;  //Turns on time counter A and sets the prescale value to 256 . 3333333/256= 13021hz (TCA0.SINGLE.CTRLA |=0b00001101)
	TCA0.SINGLE.INTCTRL |= (1<<TCA_SINGLE_OVF_bp) ; //Turns on the overflow timer on Time counter A
	TCA0.SINGLE.PER = counter; //Choose the top value to be 13021. 13021/13021= 1hz

	sei(); //turns on ISP(interrupt service routine).
}

int main(void)
{
	init_general(); //Calls the functions that turns on LED,buttons etc.
	init_timer();  //Calls the function that initiates everything for the timer.
    while (1) 
    {
		//We don't need anything here in this code
    }
}
//interrupt service routine function that gets called upon every 1s ((256*13021)/3333333) = 1s
ISR(TCA0_OVF_vect)
{
	PORTB.OUT ^= LED1_bm; //Toggle LED 1 each time it enters the ISR
	TCA0.SINGLE.INTFLAGS |= (1<<TCA_SINGLE_OVF_bp); //Turns off the interrupt flag so that the ISR can be called again
}