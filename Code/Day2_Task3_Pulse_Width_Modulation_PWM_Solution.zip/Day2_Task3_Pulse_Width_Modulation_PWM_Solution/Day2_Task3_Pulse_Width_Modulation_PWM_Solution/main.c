/*
 * Day2_Task3_Pulse_Width_Modulation_PWM_Solution.c
 *
 * Author : J�rgen Steen
 * Setup: OLED exention connected to ext1 of theAttiny817 Xplained Pro
 * Functon: In this program you change the duty-cycle of LED1 with button 1 and 2 and set it to 50% with button 3.
			Led 2 starts blinking when you have reached 0% or 100%, and Led 3 blinks when you push a button.
 */

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include <avr/interrupt.h>  //Atmel's own interrupt library

#define LED1_bm (1<<0) //LED1 on OLED
#define LED2_bm (1<<1) //LED2 on OLED
#define LED3_bm (1<<4) //LED3 on OLED
#define Button1_bm (1<<5) //button1 on OLED
#define Button2_bm (1<<6) //button2 on OLED
#define Button3_bm (1<<7) //button3 on OLED
#define button1_check (!(PORTA.IN & Button1_bm)) //button1 check to make it short and more understandable in the code.
#define button2_check (!(PORTA.IN & Button2_bm)) //button1 check
#define button3_check (!(PORTA.IN & Button3_bm)) //button1 check
//Defining my own boolean commands
#define TRUE 1   
#define FALSE 0
//Creating flags for each button to stop them from being held down
//uint8_t Button1_flag = FALSE; //these are not needed
//uint8_t Button2_flag = FALSE;
uint8_t Button3_flag = FALSE;

uint8_t Dutycycle = 50; 

#define PWM_value (uint16_t)0xffff*(1-(float)Dutycycle/100)  //Lower value to comp means higher duty cycle. 

//initiates buttons and LEDs
void General_init(void)
{
	PORTB.DIR |=  LED1_bm | LED2_bm | LED3_bm ; //Sets PB(0,1,4) as output
	//PORTB.OUT |=  LED1_bm | LED2_bm | LED3_bm ; //Sets PB(0,1,4) LOW
	PORTA.DIR &= ~Button1_bm & ~Button2_bm & ~Button3_bm; //sets PA(5,6,7) as input
	PORTA.PIN5CTRL |= (1<<PORT_PULLUPEN_bp);  //Turn on pull up
	PORTA.PIN6CTRL |= (1<<PORT_PULLUPEN_bp);  //Turn on pull up
	PORTA.PIN7CTRL |= (1<<PORT_PULLUPEN_bp);  //Turn on pull up
}
//turns on everything for the PWM
void PWM_init(void)
{	
	TCA0.SINGLE.CTRLA |= (1<<TCA_SINGLE_ENABLE_bp); //enables TCA
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_CLKSEL_DIV64_gc; //Sets the prescaler balue to 8. 3333333/64 = 52083hz
	TCA0.SINGLE.CTRLB |= TCA_SINGLE_WGMODE_SINGLESLOPE_gc; //Turns on the PWM single mode  Sometimes:  TCA_SINGLE_WGMODE_SS_gc;
	TCA0.SINGLE.CTRLB |= (1<<TCA_SINGLE_CMP0_bp);  //Turns on the  COMP0/Wo0/PB0/LED1 
	TCA0.SINGLE.INTCTRL |= (1<<TCA_SINGLE_CMP0_bp);
	TCA0.SINGLE.PER = 0xFFFF; // Sets the timer to 255. f= F_CPU/(PRescale*PER)
	TCA0.SINGLE.CMP0 = 0xFFFF;//PWM_value; //Sets the PWM value to the register which controls it.
}
void button_check(void)
{
	if (button1_check)
	{
		if (Dutycycle<100)
		{
			Dutycycle++; //increases the duty-cycle by 1
		}
		else
		{
			PORTB.OUT ^= LED2_bm; //Signals you that you have reached the top.
		}
		PORTB.OUT ^= LED3_bm;
		_delay_ms(100); //Small delay to reduce de-bouncing. Would be better to have a timer. (Look at task 1)
    }
	//increases the duty cycle
	if (button2_check)
	{
		if (Dutycycle>0)
		{
			Dutycycle--; //reduces the dutycycle by 1
		}
		else
		{
			PORTB.OUT ^= LED2_bm; //Signals you that you have reched the bottom.
		}
		PORTB.OUT ^= LED3_bm;
		_delay_ms(100);  //Small delay to reduce debouncing. Would be better to have a timer. (Look at task 1)
	}
	//Resets the duty cycle to its original value
	if (button3_check)
	{   
		if (Button3_flag ==  FALSE) //Allows action when flag is low
		{
			Button3_flag = TRUE;  //Sets flag high to hinder the action happening multiple times. 
			Dutycycle = 50;
			PORTB.OUT ^= LED3_bm;
			_delay_ms(100);  //Small delay to reduce debouncing. Would be better to have a timer. (Look at task 1)
		}
	}
	else
	{
		Button3_flag = FALSE; //resets flag
	}
}

int main(void)
{
	General_init();  //Calls the function that initiates led, button etc.
	PWM_init(); //Calls the function that initiates everything needed for PWM
	while (1)
	{
		button_check(); //checks if the buttons is pushed
		TCA0.SINGLE.CMP0 = PWM_value;
	}
}


