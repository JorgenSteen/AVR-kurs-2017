/*
 * Day3_Task3_ADC_to_PWM_Solution.c
 *
 * Created: 27.04.2017 09:33:56
 * Author : John
 *
 * Setup: io1 on ext1, OLED extension connected to ext3 on the Attiny817 Xplained Pro
 * Function: This program reads the light level and converts it into the duty-cycle of the LED
 */

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include <avr/interrupt.h>  //Atmel's own interrupt library
#include "display.h"		//Petter display library
#include <stdlib.h>			//Included since we use itoa

#define LED1_bm (1<<0) //LED1 on OLED
//Defining my own boolean commands
#define TRUE 1   
#define FALSE 0

//initiates buttons and LEDs
void General_init(void)
{
	PORTB.DIR |=  LED1_bm; //Sets PB4 as output
}

//Function that that initiates the PWM module
void PWM_init(void)
{	
	TCA0.SINGLE.CTRLA |= (1<<TCA_SINGLE_ENABLE_bp); //enables TCA
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_CLKSEL_DIV16_gc; //Sets the prescaler value to 8. 3333333/64 = 52083hz
	TCA0.SINGLE.CTRLB |= (0x03<<0); //Turns on the PWM single mode  Sometimes:  TCA_SINGLE_WGMODE_SS_gc;
	TCA0.SINGLE.CTRLB |= (1<<TCA_SINGLE_CMP0_bp);  //Turns on the  COMP0/Wo0/PB0/LED1  
	TCA0.SINGLE.INTCTRL |= (1<<TCA_SINGLE_CMP0_bp);
	TCA0.SINGLE.PER = 0x0FFF; // Sets the timer to 255. f= F_CPU/(Prescale*PER)
	TCA0.SINGLE.CMP0 = 0x00FF;//PWM_value; //Sets the PWM value to the register which controls it.
}

//Function that that initiates the ADC module
void ADC_init(void)
{
	ADC0.CTRLA |= ADC_ENABLE_bm; //Enable ADC  (ADC0.CTRLA |= 0b1;)
	ADC0.CTRLA |= ADC_RESSEL_10BIT_gc; //10-bit ADC. This is on by default, but makes it explicit for the reader.

	ADC0.CTRLC |= ADC_PRESC_DIV16_gc;    //Sets the speed of the ADC. 3333333/16 = 208333
	ADC0.CTRLC |= ADC_REFSEL_VDDREF_gc;	 //Makes the Vref VDD, 3,3V on the Xplained pro
	ADC0.CTRLC |= ADC_SAMPCAP_bm;        //Turns on a smaller capacitors since the Vref>1
	//This could also be written ADC0.CTRLC |= 0b01010011;  but that would be unreadable
}

//Write a number between 0 and 15. Find the AIN port you want to read.
uint16_t ADC_read(uint16_t Input_pin)
{
	ADC0.MUXPOS = Input_pin;  //Tells the ADC which input it shall read.
	ADC0.COMMAND |= ADC_STCONV_bm;  //Start the Analog reading. ADC0.COMMAND |= 0b1;
	while(ADC0.COMMAND & ADC_STCONV_bm){} //Makes it wait until the reading is over
	uint16_t ADC_value = ADC0.RES; //Transfers the ADC value to the variable
	char buffer[16]; //Create a buffer to dump the ascii value of the ADC_value
	itoa(ADC_value, buffer, 10); //Int to ascii from the ADC_value to the buffer
	//DISP_clear();  //clears the screen, to avoid overlay of digits on screen
	DISP_print("ADC value: "); //Prints the a description to the screen
	DISP_print(buffer); //Prints ADC_value to the screen
	DISP_print("\n");

	return(ADC0.RES);
}

int main(void)
{
	General_init();  //Calls the function that initiates led, button etc.
	DISP_init(); //initiates the screen
	PWM_init(); //Calls the function that initiates everything needed for PWM
	ADC_init(); //initiates the ADC
	while (1)
	{
		uint16_t ADC_value = ADC_read(6); //calls the ADC function
		TCA0.SINGLE.CMP0 = (ADC_value<<2); //Left shift 
		uint16_t dutycycle = 100-((float)(ADC_value<<2)/0xFFFF)*100;   //The formula for dutycycle 
		char buffer[16]; //Create a buffer to dump the ascii value of the ADC_value
		itoa(dutycycle, buffer, 10); //Int to ascii from the ADC_value to the buffer
		DISP_print("Duty-Cycle: "); //Prints the a description to the screen
		DISP_print(buffer); //Prints ADC_value to the screen
		
		DISP_print("\n"); //next line
		DISP_print("\n"); //next line
		DISP_print("\n"); //next line
	}
}




