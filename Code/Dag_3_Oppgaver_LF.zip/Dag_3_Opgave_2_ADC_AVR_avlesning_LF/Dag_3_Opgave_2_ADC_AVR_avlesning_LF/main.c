/*
 * Dag_3_Opgave_2_ADC_AVR_avlesning_LF.c
 *
 * Author : J�rgen Steen
 * Setup: io1 on ext1, OLED extension connected to ext3 with Attiny817 Xplained Pro
 * Function: This program reads the light level and prints it to the screen.
 */ 

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <avr/interrupt.h>  //Atmel's own interrupt library
#include "display.h"		//Petter display library
#include <stdlib.h>			//Included since we use itoa

//timer defines and variables. It might seem tedious to define it here, but now if you change it just here everything will follow.
#define t1 1000 //Sets the value for timer 1.  T = 1ms, T*1000=1s
#define t2 60   // 60 seconds in a minut
uint16_t timer1; //initiates timer 1
uint8_t timer2;  //initiates timer 2

volatile uint32_t ADC_SUM = 0;  //makes a global variable that can summarize the measurement
volatile uint16_t ADC_AVRG = 0; //makes a global variable that can hold the average value
volatile uint16_t measurement_nr = 0; //makes a global variable that remembers the amount of measurements
char ADC_AVRG_s[16] = "?"; //makes a global variable that can hold the average value ascii string

//Defining my own boolean commands
#define TRUE 1
#define FALSE 0
//Creating flags for various actions
uint8_t ADC_readflag = FALSE;   //A flag to tell when a measurement should be taken
uint8_t minut = FALSE; //A flag to tell when a minut has passed

//Function that that initiates the times module
void init_timer(void)
{
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm | TCA_SINGLE_CLKSEL_DIV256_gc;  //Turns on time counter A and sets the prescaler value to 256 . 3333333/256= 130020hz (TCA0.SINGLE.CTRLA |=0b00001101)
	TCA0.SINGLE.INTCTRL |= (1<<TCA_SINGLE_OVF_bp) ; //Turns on the overflow timer on Time counter A
	TCA0.SINGLE.PER = 13; //Choose the top value to be 13 130020/13= 1000hz(ish)
	timer1 = t1;  //sets time 1 to timer 1
	timer2 = t2;  //sets time 2 to timer 2
	sei(); //turns on ISP(interrupt service routine).
}

//Function that that initiates the ADC module
void init_ADC(void)
{
	ADC0.CTRLA |= ADC_ENABLE_bm; //Enable ADC  (ADC0.CTRLA |= 0b1;)
	ADC0.CTRLA |= ADC_RESSEL_10BIT_gc; //10-bit ADC. This is on by default, but makes it explicit for the reader.

	ADC0.CTRLC |= ADC_PRESC_DIV16_gc;    //Sets the speed of the ADC. 3333333/16 = 208333
	ADC0.CTRLC |= ADC_REFSEL_VDDREF_gc;	 //Makes the Vref VDD, 3,3V on the Xplained pro
	ADC0.CTRLC |= ADC_SAMPCAP_bm;        //Turns on a smaller capacitors since the Vref>1
	//This could also be written ADC0.CTRLC |= 0b01010011;  but that would be unreadable
}

//Write a number between 0 and 15. Find the AIN port you want to read.
uint16_t ADC_read(uint16_t Input_pin)
{
	ADC0.MUXPOS = Input_pin;  //Tells the ADC which input it shall read.
	ADC0.COMMAND |= ADC_STCONV_bm;  //Start the Analog reading. ADC0.COMMAND |= 0b1;
	while(ADC0.COMMAND & ADC_STCONV_bm){} //Makes it wait until the reading is over
	return ADC0.RES;  //Dumps the reading into a variable
}

//This function checks all of the timers and resets them if they have reached 0.
void Time_check(void)
{
	//timer one measure when a second has passed
	if ( timer1 == 0)
	{
		ADC_readflag = TRUE; //sets the read flag high
		timer1 = t1; //Sets timer 1 to its initial value.
		timer2--;  //takes a second of a minute
	}
	//timer one measure when a minute has passed
	if (timer2 <=0)
	{
		timer2 = t2; //Sets timer 2 to its initial value.
		minut = TRUE; //Sets the minute flag high
	}
}

//This function checks if it is time to take a measurement and/or an average measurement
void measure_and_print(void)
{
	//Creates an average result each minute
	if (minut == TRUE)
	{
		minut = FALSE;  //sets the minute flag low
		ADC_AVRG = ADC_SUM/measurement_nr; //Creates an average
		ADC_SUM = 0; //resets the summarizer
		measurement_nr = 0; //resets the measurement count
		itoa(ADC_AVRG,ADC_AVRG_s,10);  //integer to ASCII the average 
	}
	if (ADC_readflag == TRUE)
	{
		ADC_readflag = FALSE;
		uint16_t ADC_value = ADC_read(6);  //request a reading from the ADC function
		ADC_SUM = ADC_SUM + ADC_value; //Adds the values to the summarizer
		measurement_nr++; //Keep track of how many measurements has been taken
		char buffer[16]; //Creates a buffer to dump the ascii value of the ADC_value

		itoa(ADC_value, buffer, 10); //Int to ascii from the ADC_value to the buffer
		DISP_clear();  //clears the screen, to avoid overlaying digits on screen
		DISP_print("ADC value: "); //Prints a description to the screen
		DISP_print(buffer); //Prints ADC_value to the screen
        DISP_print("\n"); //next line

		DISP_print("ADC AVRG: "); //Prints a description to the screen
		DISP_print(ADC_AVRG_s); //Prints ADC_AVRG to the screen
		DISP_print("\n"); //next line
	}
	
}

int main(void)
{
	DISP_init();  //initiates the screen
	init_timer();  //Calls the function that initiates everything for the timer.
	init_ADC();  //initiates the ADC
	while (1)
	{
		Time_check(); //Checks if the timers have counted to 0.
		measure_and_print();  //Checks if its time to measure and print
	}
}

//interrupt service routine function that gets called upon every 1ms ((256*13)/3333333) = 1ms(ish)
ISR(TCA0_OVF_vect)
{
	//Counts down the button timer if the value has been set.
	if (timer1>0)
	{
		timer1 = timer1-1;
	}
	TCA0.SINGLE.INTFLAGS |= (1<<TCA_SINGLE_OVF_bp);
}