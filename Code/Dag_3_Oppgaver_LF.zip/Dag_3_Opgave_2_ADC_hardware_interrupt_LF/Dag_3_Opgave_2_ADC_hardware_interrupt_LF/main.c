/*
 * Dag_3_Opgave_4_ADC_hardware_interrupt_LF.c
 *
 * Created: 20.04.2017 19:31:55
 * Author : John
* Setup: OLED extension connected to ext1 of theAttiny817 Xplained Pro
* Function: Using a hardware interrupt to toggle a led.
*/

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include <avr/interrupt.h>  //Atmel's own interrupt library
#include "display.h"		//Petter display library
#include <stdlib.h>			//Included since we use itoa

#define LED1_bm (1<<4) //LED0 on the Explained
#define Button1_bm (1<<6) //Button1 on OLED ext1
#define Button1_check (!(PORTB.IN & Button1_bm))  //button1 check to make it short and more understandable in the code.
//Defining my own boolean commands
#define TRUE 1
#define FALSE 0
//Creating flags for button1 to keep it from being activated multiple times if it is being held down
uint8_t Button1_flag = FALSE;

//Function that initiates led & button
void init_generelt(void)
{
	PORTB.DIR |=  LED1_bm; //Sets PB4 as an output
	PORTB.DIR &= ~Button1_bm; //Sets PB6 as an input. They are set as this by default, but this makes it explicits for the reader.
	PORTB.PIN6CTRL |= (1<<PORT_PULLUPEN_bp);  //Turns on the pull-up resistor on PORTA5/button1
	PORTB.PIN6CTRL |= PORT_ISC_FALLING_gc;	// falling edge on PA5. This is preferred when the button is pulled up
	sei();  //turns on ISP(interrupt service routine).
}

//Function that that initiates the ADC module
void init_ADC(void)
{
	ADC0.CTRLA |= ADC_ENABLE_bm; //Enable ADC  (ADC0.CTRLA |= 0b1;)
	ADC0.CTRLA |= ADC_RESSEL_10BIT_gc; //10-bit ADC. This is on by default, but makes it explicit for the reader.

	ADC0.CTRLC |= ADC_PRESC_DIV16_gc;    //Sets the speed of the ADC. 3333333/16 = 208333
	ADC0.CTRLC |= ADC_REFSEL_VDDREF_gc;	 //Makes the Vref VDD, 3,3V on the Xplained pro
	ADC0.CTRLC |= ADC_SAMPCAP_bm;        //Turns on a smaller capacitors since the Vref>1
	//This could also be written ADC0.CTRLC |= 0b01010011;  but that would be unreadable
}

//this button reads the button value and sets the flag low if its not pressed
void Button_check(void)
{
	if (!Button1_check)
	{
		Button1_flag = FALSE; //Sets the flag low
	}
}



//Write a number between 0 and 15. Find the AIN port you want to read.
void ADC_read(uint16_t Input_pin)
{
	ADC0.MUXPOS = Input_pin;  //Tells the ADC which input it shall read.
	ADC0.COMMAND |= ADC_STCONV_bm;  //Start the Analog reading. ADC0.COMMAND |= 0b1;
	while(ADC0.COMMAND & ADC_STCONV_bm){} //Makes it wait until the reading is over
	uint16_t ADC_Value = ADC0.RES;  //Dumps the reading into a variable
	char buffer[16]; //Create a buffer to dump the ascii value of the ADC_value
	itoa(ADC_Value, buffer, 10); //Int to ascii from the ADC_value to the buffer
	DISP_clear(); //clears the screen, to avoid overlay of digits on screen
	DISP_print("ADC value: "); //Prints the a description to the screen
	DISP_print(buffer); //Prints ADC_value to the screen
}

int main(void)
{
	DISP_init();  //initiates the screen
	init_ADC();  //initiates the ADC
	init_generelt(); //Calls the functions that turns on LED,buttons etc.
	while (1)
	{
		Button_check(); //Checks button status
	}
}

ISR(PORTB_PORT_vect)
{
	//checks the status of button 1. It should be high, but this ISR gets activated by any PORTA interrupt
	if (Button1_check)
	{
		if (Button1_flag ==  FALSE)
		{
			ADC_read(6); //Request a reading on AIN6 through our own function
			Button1_flag = TRUE; //Sets the button flag high
			PORTB.OUT ^= LED1_bm; //Indicate a button was pressed

		}
	}
}