/*
 * Day3_Task1_Analog_to_Digital_ADC_Solution.c
 *
 * Author : J�rgen Steen
 * Setup: io1 on ext1, OLED extension connected to ext3 on Attiny817 Xplained Pro
 * Function: This program reads the light level and prints it to the screen.
 */ 

#include <avr/io.h>         // A part of all AVR-programming for convenient programming
#define F_CPU 3333333UL     //The internal clock is 20Mhz, but it can't run that fast with 3,3V so it is prescaled by a factor of 6 to 3333333
#include <util/delay.h>     //Delay Library
#include "display.h"		//Petter display library
#include <stdlib.h>			//Included so this since we use itoa

//Function that that initiates the ADC modul
void init_ADC(void)
{
	ADC0.CTRLA |= ADC_ENABLE_bm; //Enable ADC  (ADC0.CTRLA |= 0b1;)
	ADC0.CTRLA |= ADC_RESSEL_10BIT_gc; //10-bit ADC. This is on by default, but makes it explicit for the reader.

	ADC0.CTRLC |= ADC_PRESC_DIV16_gc;    //Sets the speed of the ADC. 3333333/16 = 208333
	ADC0.CTRLC |= ADC_REFSEL_VDDREF_gc;	 //Makes the Vref VDD, 3,3V on the Xplained pro	             
	ADC0.CTRLC |= ADC_SAMPCAP_bm;        //Turns on a smaller capacitors since the Vref>1
	//This could also be written ADC0.CTRLC |= 0b01010011;  but that would be unreadable
}

//Write a number between 0 and 15. Find the AIN port you want to read.
void ADC_read(uint16_t Input_pin)
{
	ADC0.MUXPOS = Input_pin;  //Tells the ADC which input it shall read. 
	ADC0.COMMAND |= ADC_STCONV_bm;  //Start the Analog reading. ADC0.COMMAND |= 0b1;
	while(ADC0.COMMAND & ADC_STCONV_bm){} //Makes it wait until the reading is over
	uint16_t ADC_Value = ADC0.RES;  //Dumps the reading into a variable
	char buffer[16]; //Create a buffer for making to dump the ascii value of the ADC_value
	itoa(ADC_Value, buffer, 10); //Int to ascii from the ADC_value to the buffer
	DISP_clear();  //clears the screen, this will cause blinking and can be avoided if remove this and always print 4 digits.
	DISP_print("ADC value: "); //Prints the a description to the screen
	DISP_print(buffer); //Prints ADC_value to the screen
}

int main(void)
{
	DISP_init();  //initiates the OLED
	init_ADC();  //initiates the ADC
	while (1)
	{
		ADC_read(6); //Request a reading on AIN6 through our own function
		_delay_ms(1000);  //delay make it everything slow down.
	}
}


