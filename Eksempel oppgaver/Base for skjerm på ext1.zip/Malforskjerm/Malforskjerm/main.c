/*
 * Malforskjerm.c
 *
 * Created: 02.04.1968 21:46:40
 * Author : HAL9000
 * SKJERM P� EXT1
 * Dette programmet er ment for � bruke som grunnlag for nybegynner som vil kun bruke skjermen for praktiske egenskaper.
 */ 

 #define  F_CPU 3333333UL
#include <avr/io.h>
#include <util/delay.h>
#include "display.h"

int main(void)
{
	DISP_init();
	DISP_print("Open the podbay door please HAL");
	DISP_print("\n");
	_delay_ms(4500);
	DISP_print("HAL do you read me HAL?");
	_delay_ms(3500);
	DISP_clear();
	DISP_print("Affirmative Dave I can hear you\n");
	_delay_ms(2500);
		
	DISP_print("Open the podbay door HAL");
	_delay_ms(2500);
	DISP_clear();
	DISP_print("I'm sorry Dave,\n");
	DISP_print("I am afraid i");
	DISP_print("    ");
	 DISP_print("can't do that.");


    /* Replace with your application code */
    while (1) 
    {

    }
}

